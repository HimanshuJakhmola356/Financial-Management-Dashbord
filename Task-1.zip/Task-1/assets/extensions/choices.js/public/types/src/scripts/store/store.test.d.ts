export {};
//# sourceMappingURL=store.test.d.ts.map